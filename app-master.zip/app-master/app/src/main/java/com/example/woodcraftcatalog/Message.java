package com.example.woodcraftcatalog;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Message extends AppCompatActivity {
    Button btn;
    EditText numtxt;
    String snum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        btn = findViewById(R.id.btnCall);
        numtxt = findViewById(R.id.numtxt);


    }
   public void btncall (View v){
        Intent i = new Intent(Intent.ACTION_CALL);
        snum = numtxt.getText().toString();
        if (snum.trim().isEmpty()){
            i.setData(Uri.parse("tel:123456789"));
        }
        else{
            i.setData(Uri.parse("tel:"+snum));
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, "Please grant the permission to call", Toast.LENGTH_SHORT).show();
            requestPermissions();
        }
        else {
            startActivity(i);
        }
   }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE},1);
    }
}